<?php
session_start();

# If the admin is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {

    # Database Connection File
    include "../db_conn.php";

    if (isset($_POST['book_title']) && isset($_POST['book_author']) && isset($_POST['book_category']) && isset($_POST['book_description']) && isset($_POST['stock_quantity']) && isset($_POST['price'])) {
        
        $book_title = $_POST['book_title'];
        $book_author = $_POST['book_author'];
        $book_category = $_POST['book_category'];
        $book_description = $_POST['book_description'];
        $stock_quantity = $_POST['stock_quantity'];
        $price = $_POST['price'];
        
        $book_cover = $_FILES['book_cover']['name'];
        $book_cover_tmp_name = $_FILES['book_cover']['tmp_name'];
        $book_cover_folder = '../uploads/books/' . $book_cover;

        $book_file = $_FILES['book_file']['name'];
        $book_file_tmp_name = $_FILES['book_file']['tmp_name'];
        $book_file_folder = '../uploads/files/' . $book_file;

        if (empty($book_title) || empty($book_author) || empty($book_category) || empty($book_description) || empty($stock_quantity) || empty($price)) {
            $em = urlencode("All fields are required");
            header("Location: ../add-book.php?error=$em");
            exit;
        } else {
            move_uploaded_file($book_cover_tmp_name, $book_cover_folder);
            move_uploaded_file($book_file_tmp_name, $book_file_folder);

            $sql = "INSERT INTO books (title, author_id, category_id, description, cover, file, stock_quantity, price) VALUES (?,?,?,?,?,?,?,?)";
            $stmt = $conn->prepare($sql);
            if ($stmt->execute([$book_title, $book_author, $book_category, $book_description, $book_cover, $book_file, $stock_quantity, $price])) {
                $sm = urlencode("Book added successfully");
                header("Location: ../add-book.php?success=$sm");
                exit;
            } else {
                $em = urlencode("Failed to add book");
                header("Location: ../add-book.php?error=$em");
                exit;
            }
        }
    } else {
        $em = urlencode("Invalid input");
        header("Location: ../add-book.php?error=$em");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>
