<?php
// Function to get all customers
function get_all_customers($conn) {
    $stmt = $conn->prepare("SELECT * FROM customers");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get a customer by ID
function get_customer_by_id($conn, $customer_id) {
    $stmt = $conn->prepare("SELECT * FROM customers WHERE customer_id = :customer_id");
    $stmt->bindParam(':customer_id', $customer_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Function to create a new customer
function create_customer($conn, $name, $email, $password) {
    $stmt = $conn->prepare("INSERT INTO customers (name, email, password) VALUES (:name, :email, :password)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', password_hash($password, PASSWORD_DEFAULT));
    return $stmt->execute();
}

// Function to update a customer
function update_customer($conn, $customer_id, $name, $email, $password) {
    $stmt = $conn->prepare("UPDATE customers SET name = :name, email = :email, password = :password WHERE customer_id = :customer_id");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', password_hash($password, PASSWORD_DEFAULT));
    $stmt->bindParam(':customer_id', $customer_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Function to delete a customer
function delete_customer($conn, $customer_id) {
    $stmt = $conn->prepare("DELETE FROM customers WHERE customer_id = :customer_id");
    $stmt->bindParam(':customer_id', $customer_id, PDO::PARAM_INT);
    return $stmt->execute();
}
?>
