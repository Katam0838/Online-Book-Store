<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_email'])) {
  header("Location: login.php");
  exit;
}

if (isset($_GET['customer_id'])) {
  include "db_conn.php";
  $id = $_GET['customer_id'];
  $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
  $stmt->execute([$id]);
}

header("Location: admin.php");
exit;
?>
