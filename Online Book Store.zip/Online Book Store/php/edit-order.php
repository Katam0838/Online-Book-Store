<?php  
session_start();

# If the admin is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {

    # Database Connection File
    include "../db_conn.php";

    if (isset($_POST['order_id']) && isset($_POST['customer_id']) && isset($_POST['book_id']) && isset($_POST['quantity']) && isset($_POST['order_date'])) {
        
        $order_id = $_POST['order_id'];
        $customer_id = $_POST['customer_id'];
        $book_id = $_POST['book_id'];
        $quantity = $_POST['quantity'];
        $order_date = $_POST['order_date'];

        if (empty($customer_id) || empty($book_id) || empty($quantity) || empty($order_date)) {
            $em = urlencode("All fields are required");
            header("Location: ../edit-order.php?id=$order_id&error=$em");
            exit;
        } else {
            $sql = "UPDATE orders SET customer_id=?, book_id=?, quantity=?, order_date=? WHERE order_id=?";
            $stmt = $conn->prepare($sql);
            if ($stmt->execute([$customer_id, $book_id, $quantity, $order_date, $order_id])) {
                $sm = urlencode("Order updated successfully");
                header("Location: ../edit-order.php?id=$order_id&success=$sm");
                exit;
            } else {
                $em = urlencode("Failed to update order");
                header("Location: ../edit-order.php?id=$order_id&error=$em");
                exit;
            }
        }

    } else {
        $em = urlencode("Invalid input");
        header("Location: ../edit-order.php?id=$order_id&error=$em");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>
