<?php
// Function to get all authors
function get_all_authors($conn) {
    $stmt = $conn->prepare("SELECT * FROM authors");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get an author by ID
function get_author_by_id($conn, $author_id) {
    $stmt = $conn->prepare("SELECT * FROM authors WHERE author_id = :author_id");
    $stmt->bindParam(':author_id', $author_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Function to create a new author
function create_author($conn, $name) {
    $stmt = $conn->prepare("INSERT INTO authors (name) VALUES (:name)");
    $stmt->bindParam(':name', $name);
    return $stmt->execute();
}

// Function to update an author
function update_author($conn, $author_id, $name) {
    $stmt = $conn->prepare("UPDATE authors SET name = :name WHERE author_id = :author_id");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':author_id', $author_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Function to delete an author
function delete_author($conn, $author_id) {
    $stmt = $conn->prepare("DELETE FROM authors WHERE author_id = :author_id");
    $stmt->bindParam(':author_id', $author_id, PDO::PARAM_INT);
    return $stmt->execute();
}
?>
