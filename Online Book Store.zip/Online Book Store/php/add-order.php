<?php
session_start();

if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['customer_id']) && isset($_POST['book_id']) && isset($_POST['order_date']) && isset($_POST['quantity'])) {
            include "../db_conn.php";

            $customer_id = $_POST['customer_id'];
            $book_id = $_POST['book_id'];
            $order_date = $_POST['order_date'];
            $quantity = $_POST['quantity'];

            // Fetch book price
            $stmt = $conn->prepare("SELECT price FROM books WHERE book_id = ?");
            $stmt->execute([$book_id]);
            $book = $stmt->fetch();

            if ($book) {
                $total_price = $book['price'] * $quantity;

                $sql = "INSERT INTO orders (customer_id, book_id, order_date, quantity, total_price) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if ($stmt->execute([$customer_id, $book_id, $order_date, $quantity, $total_price])) {
                    header("Location: ../add-order.php?success=Order added successfully");
                    exit();
                } else {
                    header("Location: ../add-order.php?error=Failed to add order");
                    exit();
                }
            } else {
                header("Location: ../add-order.php?error=Invalid book selected");
                exit();
            }
        } else {
            header("Location: ../add-order.php?error=All fields are required");
            exit();
        }
    } else {
        header("Location: ../add-order.php");
        exit();
    }
} else {
    header("Location: ../login.php");
    exit();
}
?>
