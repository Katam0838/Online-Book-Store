<?php  
session_start();

# If the admin is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {

    # Database Connection File
    include "../db_conn.php";

    if (isset($_GET['id'])) {
        $order_id = $_GET['id'];

        # Check if the order exists
        $sql = "SELECT * FROM orders WHERE order_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$order_id]);

        if ($stmt->rowCount() > 0) {
            $sql = "DELETE FROM orders WHERE order_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$order_id]);

            $sm = "Order deleted successfully";
            header("Location: ../view-orders.php?success=$sm");
            exit;
        } else {
            $em = "Order not found";
            header("Location: ../view-orders.php?error=$em");
            exit;
        }
    } else {
        header("Location: ../view-orders.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>
